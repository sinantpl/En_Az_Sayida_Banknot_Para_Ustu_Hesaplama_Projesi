Kütüphanelerin kurulumu ile ilgili daha fazla bilgi için şu adresi ziyaret edin: http://www.arduino.cc/en/Guide/Libraries
